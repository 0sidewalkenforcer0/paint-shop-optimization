import numpy as np

class naive():

    def __init__(self):
        pass

    def findSolution(self, sequence):
        pass